# Docker Instructions

Note: you must have docker installed locally to follow this guide

1. Download the entire folder to a location on your local computer
2. Navigate to the folder in command prompt, powershell, or terminal depending on the type of machine
3. From the Docker_Dashboard directory, run the following command to build the application image:
    > docker build . -t techstat_app
4. After this process completes, from the same command prompt/terminal window, run the following commmand:
    > docker run -p 8080:8080 techstat_app
5. Once this executes, you should start seeing some log output in your window, like the below:
    > Dash is running on http://0.0.0.0:8080/
6. Open a browser, and navigate to localhost:8080 in the navigation bar
7. You will now see the application, and can access it normally

To log into the provider page, the user/password is as follows:
    User: dr_jones
    Password: techstat_dashboard