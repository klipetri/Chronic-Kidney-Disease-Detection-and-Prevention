import dash
from dash import html, dcc, Input, Output, State
import flask
from flask_login import login_user, LoginManager, UserMixin, logout_user, current_user
from app import app
from app import server
from layouts import provider_page, information_page, prediction_page, login, success, failed, logout, information_page_mobile, prediction_page_mobile, provider_page_mobile
import callbacks


login_manager = LoginManager()
login_manager.init_app(server)
login_manager.login_view = '/login'

class User(UserMixin):
    def __init__(self, username):
        self.id = username

@ login_manager.user_loader
def load_user(username):
        return User(username)

@app.callback(
    Output('url_login', 'pathname'), Output('output-state', 'children'), [Input('login-button', 'n_clicks')], [State('uname-box', 'value'), State('pwd-box', 'value')])
def login_button_click(n_clicks, username, password):
    if n_clicks > 0:
        if username == 'dr_jones' and password == 'techstat_dashboard':
            user = User(username)
            login_user(user)
            return '/apps/success', ''
        elif username == 'dashboard_admin' and password == 'techstat_admin':
            user = User(username)
            login_user(user)
            return '/apps/success', ''
        else:
            return '/apps/login', html.Div('Incorrect username or password',style={'color' : 'rgb(251, 251, 252)'})


app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    dcc.Location(id='redirect', refresh=True),
    dcc.Store(id='login-status', storage_type='session'),
    html.Div(id='user-status-div',style={'background-color' : 'rgb(0, 31, 77)'}),
    html.Div(id='page-content')
],style={  'background-size': '100%',
          'width': '100vw',
          'height': '100vh',
          'background-color' : 'rgb(0, 31, 77)'
          })


@app.callback(Output('user-status-div', 'children'), Output('login-status', 'data'), [Input('url', 'pathname')])
def login_status(url):
    ''' callback to display login/logout link in the header '''
    if hasattr(current_user, 'is_authenticated') and current_user.is_authenticated \
            and url != '/apps/logout':  
        return dcc.Link('logout', href='/apps/logout'), current_user.get_id()
    else:
        return dcc.Link('login', href='/apps/login'), 'loggedout'

@app.callback(dash.dependencies.Output('page-content', 'children'), Output('redirect', 'pathname'),
              [dash.dependencies.Input('url', 'pathname')])
def display_page(pathname):
    view = None
    url = dash.no_update
    if pathname == '/apps/login':
        view = login
    elif pathname == '/apps/success':
        if current_user.is_authenticated:
            view = provider_page
        else:
            view = failed
    elif pathname == '/apps/logout':
        if current_user.is_authenticated:
            logout_user()
            view = logout
        else:
            view = login
            url = '/apps/login'

    elif pathname == '/apps/overview':
         view = information_page
    elif pathname == '/apps/mobile/overview':
         view = information_page_mobile
    elif pathname == '/apps/predictions':
         view = prediction_page
    elif pathname == '/apps/mobile/predictions':
         view = prediction_page_mobile
    elif pathname == '/apps/provider':
        if current_user.is_authenticated:
            view = provider_page
        else:
            view = 'Redirecting to login...'
            url = '/apps/login'
    elif pathname == '/apps/mobile/provider':
        if current_user.is_authenticated:
            view = provider_page_mobile
        else:
            view = 'Redirecting to login...'
            url = '/apps/login'
    else:
        view = prediction_page

    return view, url

if __name__ == '__main__':
    app.run_server(host="0.0.0.0", port=8080, debug=False)
