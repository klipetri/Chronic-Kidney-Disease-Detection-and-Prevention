import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
import numpy as np
import dash
from dash import dcc, html, dash_table
from dash.dash_table.Format import Format, Group, Scheme
from dash.dash_table import FormatTemplate as FormatTemplate
from datetime import datetime as dt
from app import app
import joblib
import pickle
from sklearn import decomposition
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

#####
# Formatting for colors and stuff
#####

techstat_colors = {
    'dark-blue-grey' : 'rgb(62, 64, 76)',
    'medium-blue' : 'rgb(51, 133, 255)',
    'superdark-blue' : 'rgb(0, 31, 77)',
    'dark-blue' : 'rgb(0, 51, 128)',
    'medium-green' : 'rgb(93, 113, 120)',
    'light-blue' : 'rgb(153, 194, 255)',
    'pink-red' : 'rgb(255, 101, 131)',
    'dark-pink-red' : 'rgb(247, 80, 99)',
    'white' : 'rgb(251, 251, 252)',
    'light-grey' : 'rgb(208, 206, 206)'
}

externalgraph_rowstyling = {
    #'margin-left' : '15px',
    #'margin-right' : '15px',
    'background-color' : techstat_colors['dark-blue']
}

externalgraph_colstyling = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : techstat_colors['superdark-blue'],
    'background-color' : techstat_colors['superdark-blue'],
    'box-shadow' : '0px 0px 17px 0px rgba(186, 218, 212, .5)',
    'padding-top' : '10px'
}

filterdiv_borderstyling = {
    'border-radius' : '0px 0px 10px 10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : techstat_colors['light-blue'],
    'background-color' : techstat_colors['light-blue'],
    'box-shadow' : '2px 5px 5px 1px rgba(255, 101, 131, .5)'
    }

navbarcurrentpage = {
    'text-decoration' : 'underline',
    'text-decoration-color' : techstat_colors['pink-red'],
    'text-shadow': '0px 0px 1px rgb(251, 251, 252)'
    }

recapdiv = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : 'rgb(251, 251, 252, 0.1)',
    'margin-left' : '15px',
    'margin-right' : '15px',
    'margin-top' : '15px',
    'margin-bottom' : '15px',
    'padding-top' : '5px',
    'padding-bottom' : '5px',
    'background-color' : 'rgb(251, 251, 252, 0.1)'
    }

recapdiv_text = {
    'text-align' : 'left',
    'font-weight' : '350',
    'color' : techstat_colors['white'],
    'font-size' : '1.5rem',
    'letter-spacing' : '0.04em'
    }

techstat_font_family = 'Dosis'


######
# Mapping input data
#####

#map field names in data source to more readable names
ckd_filepath = 'data/CKD_CLEANED.csv'

ckd_fields = {
    'ID' : 'id',
    'Age' : 'age',
    'Blood Pressure' : 'bp',
    'Specific Gravity' : 'sg',
    'Albumin' : 'al',
    'Sugar' : 'su',
    'Red Blood Cells' : 'rbc',
    'Pus Cells' : 'pc',
    'Pus Cell Clumps' : 'pcc',
    'Bacteria' : 'ba',
    'Blood Glucose Random' : 'bgr',
    'Blood Urea' : 'bu',
    'Serum Creatinine' : 'sc',
    'Sodium' : 'sod',
    'Potassium' : 'pot',
    'Hemoglobin' : 'hemo',
    'Packed Cell Volume' : 'pcv',
    'White Blood Cell Count' : 'wc',
    'Red Blood Cell Count' : 'rc',
    'Hypertension' : 'htn',
    'Diabetes Mellitus' : 'dm',
    'Coronary Artery Disease' : 'cad',     
    'Appetite' : 'appet',
    'Pedal Edema' : 'pe',
    'Anemia' : 'ane',
    'Class' : 'classification'
    }



######
# Import the data set(s)
######


#Import ckd data into a dataframe
ckd = pd.read_csv(ckd_filepath)
# strip all whitespace from cells
ckd = ckd.apply(lambda x: x.str.strip() if x.dtype == "object" else x)


# Dropdown options for classification pick list
classification_l1 = ckd[ckd_fields['Class']].unique()
classification_l1_all_2 = [
    {'label' : k, 'value' : k} for k in sorted(classification_l1)
    ]
classification_l1_all_1 = [{'label' : '(Select All)', 'value' : 'All'}]
classification_l1_all = classification_l1_all_1 + classification_l1_all_2

# Dropdown options for diabetes pick list, just as an example
diabetes_groups_l2 = ckd[ckd_fields['Diabetes Mellitus']].unique()
diabetes_groups_l2_all_2 = [
    {'label' : k, 'value' : k} for k in diabetes_groups_l2 #sorted(diabetes_groups_l2) # why doesn't sorting work here?????
    ]
diabetes_groups_l2_all_1 = [{'label' : '(Select All)', 'value' : 'All'}]
diabetes_groups_l2_all = diabetes_groups_l2_all_1 + diabetes_groups_l2_all_2

# to cascade if multiple filters are selected
both_groups_l1_l2 = {}
for l1 in classification_l1:
    l2 = ckd[ckd[ckd_fields['Class']] == l1][ckd_fields['Diabetes Mellitus']].unique()
    both_groups_l1_l2[l1] = l2



# Dropdown options for classification pick list mobile
classification_l1_mobile = ckd[ckd_fields['Class']].unique()
classification_l1_all_2_mobile = [
    {'label' : k, 'value' : k} for k in sorted(classification_l1_mobile)
    ]
classification_l1_all_1_mobile = [{'label' : '(Select All)', 'value' : 'All'}]
classification_l1_all_mobile = classification_l1_all_1_mobile + classification_l1_all_2_mobile

# Dropdown options for diabetes pick list, just as an example
diabetes_groups_l2_mobile = ckd[ckd_fields['Diabetes Mellitus']].unique()
diabetes_groups_l2_all_2_mobile = [
    {'label' : k, 'value' : k} for k in diabetes_groups_l2_mobile #sorted(diabetes_groups_l2) # why doesn't sorting work here?????
    ]
diabetes_groups_l2_all_1_mobile = [{'label' : '(Select All)', 'value' : 'All'}]
diabetes_groups_l2_all_mobile = diabetes_groups_l2_all_1_mobile + diabetes_groups_l2_all_2_mobile

# to cascade if multiple filters are selected
both_groups_l1_l2_mobile = {}
for l1_mobile in classification_l1_mobile:
    l2_mobile = ckd[ckd[ckd_fields['Class']] == l1_mobile][ckd_fields['Diabetes Mellitus']].unique()
    both_groups_l1_l2_mobile[l1] = l2_mobile

######
# Helper functions
#####


#####
# Dynamic Dropdown setup
#####
@app.callback(
    dash.dependencies.Output('diabetes_dropdown', 'options'),
    [dash.dependencies.Input('classification_dropdown', 'value')])
def l2dropdown_options(l1_dropdown_value):
    isselect_all = 'Start' #Initialize isselect_all
    #Rembember that the dropdown value is a list !
    for i in l1_dropdown_value:
        if i == 'All':
            isselect_all = 'Y'
            break
        elif i != '':
            isselect_all = 'N'
        else:
            pass
    #Create options for individual selections
    if isselect_all == 'N':
        options_0 = []
        for i in l1_dropdown_value:
            options_0.append(both_groups_l1_l2[i])
        options_1 = [] # Extract string of string
        for i1 in options_0:
            for i2 in i1:
                options_1.append(i2)
        options_list = [] # Get unique values from the string
        for i in options_1:
            if i not in options_list:
                options_list.append(i)
            else:
                pass
        options_final_1 = [
            {'label' : k, 'value' : k} for k in options_list] #sorted(options_list)]
        options_final_0 = [{'label' : '(Select All)', 'value' : 'All'}]
        options_final = options_final_0 + options_final_1
    #Create options for select all or none
    else:
        options_final_1 = [
            {'label' : k, 'value' : k} for k in diabetes_groups_l2 ] #sorted(diabetes_groups_l2)]
        options_final_0 = [{'label' : '(Select All)', 'value' : 'All'}]
        options_final = options_final_0 + options_final_1

    return options_final


#####
# Dynamic Dropdown setup mobile
#####
@app.callback(
    dash.dependencies.Output('diabetes_dropdown_mobile', 'options'),
    [dash.dependencies.Input('classification_dropdown_mobile', 'value')])
def l2dropdown_options(l1_dropdown_value):
    isselect_all = 'Start' #Initialize isselect_all
    #Rembember that the dropdown value is a list !
    for i in l1_dropdown_value:
        if i == 'All':
            isselect_all = 'Y'
            break
        elif i != '':
            isselect_all = 'N'
        else:
            pass
    #Create options for individual selections
    if isselect_all == 'N':
        options_0 = []
        for i in l1_dropdown_value:
            options_0.append(both_groups_l1_l2[i])
        options_1 = [] # Extract string of string
        for i1 in options_0:
            for i2 in i1:
                options_1.append(i2)
        options_list = [] # Get unique values from the string
        for i in options_1:
            if i not in options_list:
                options_list.append(i)
            else:
                pass
        options_final_1 = [
            {'label' : k, 'value' : k} for k in options_list] #sorted(options_list)]
        options_final_0 = [{'label' : '(Select All)', 'value' : 'All'}]
        options_final = options_final_0 + options_final_1
    #Create options for select all or none
    else:
        options_final_1 = [
            {'label' : k, 'value' : k} for k in diabetes_groups_l2 ] #sorted(diabetes_groups_l2)]
        options_final_0 = [{'label' : '(Select All)', 'value' : 'All'}]
        options_final = options_final_0 + options_final_1

    return options_final



######
# Set up summary table
######
@app.callback(
    [dash.dependencies.Output('recap-table', 'data'), dash.dependencies.Output('recap-table', 'columns')], #dash.dependencies.Output('recap-table', 'style_data_conditional')],
	[dash.dependencies.Input('classification_dropdown', 'value'), dash.dependencies.Input('diabetes_dropdown', 'value')])

def update_chart(classification_dropdown, diabetes_dropdown):

    # Filter summary table based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    # Aggregate df
    metrics = ['Total Patients', 'Patients with CKD', 'Patients w/o CKD']
    value = [df_1[ckd_fields['ID']].nunique(), df_1[ckd_fields['Class']].value_counts().get('yes',0), df_1[ckd_fields['Class']].value_counts().get('no',0)]
    df = pd.DataFrame({'Metrics' : metrics, 'Value' : value})

    # set up data to display in summary table
    data = df.to_dict('records')
    columns = [
        {'id' : 'Metrics', 'name' : 'Metrics'},
        {'id' : 'Value', 'name': 'Value', 'type': 'numeric', 'format' : Format(scheme=Scheme.fixed, precision=2, group=Group.yes, group_delimiter=',', decimal_delimiter='.')}
    ]

    return data, columns

######
# Set up summary table mobile
######
@app.callback(
    [dash.dependencies.Output('recap-table-mobile', 'data'), dash.dependencies.Output('recap-table-mobile', 'columns')],
	[dash.dependencies.Input('classification_dropdown_mobile', 'value'), dash.dependencies.Input('diabetes_dropdown_mobile', 'value')])

def update_chart(classification_dropdown_mobile, diabetes_dropdown_mobile):

    # Filter summary table based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown_mobile:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown_mobile), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown_mobile:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown_mobile), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    # Aggregate df
    metrics = ['Total Patients', 'Patients with CKD', 'Patients w/o CKD']
    value = [df_1[ckd_fields['ID']].nunique(), df_1[ckd_fields['Class']].value_counts().get('yes',0), df_1[ckd_fields['Class']].value_counts().get('no',0)]
    df = pd.DataFrame({'Metrics' : metrics, 'Value' : value})

    # set up data to display in summary table
    data = df.to_dict('records')
    columns = [
        {'id' : 'Metrics', 'name' : 'Metrics'},
        {'id' : 'Value', 'name': 'Value', 'type': 'numeric', 'format' : Format(scheme=Scheme.fixed, precision=2, group=Group.yes, group_delimiter=',', decimal_delimiter='.')}
    ]

    return data, columns

######
# Set up patient list table
######
@app.callback(
    [dash.dependencies.Output('patient-list', 'data',allow_duplicate=True), dash.dependencies.Output('patient-list', 'columns')],
    [dash.dependencies.Input('classification_dropdown', 'value'), dash.dependencies.Input('diabetes_dropdown', 'value')],
    prevent_initial_call='initial_duplicate'
    )

def update_chart(classification_dropdown, diabetes_dropdown):

    # Filter patient list table based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    new_names = {'id' : 'Patient ID', 'age' : 'Age', 'bp' : 'Blood Pressure', 'sg' : 'Specific Gravity', 'al' : 'Albumin', 'su' : 'Sugar', 'rbc' : 'Red Blood Cells',
                    'pc' : 'Pus Cells', 'pcc' : 'Pus Cell Clumps', 'ba' : 'Bacteria', 'bgr' : 'Blood Glucose Random', 'bu' : 'Blood Urea', 'sc' : 'Serum Creatinine',
                    'sod' : 'Sodium', 'pot' : 'Potassium', 'hemo' : 'Hemoglobin', 'pcv' : 'Packed Cell Volume', 'wc' : 'White Blood Cell Count', 'rc' : 'Red Blood Cell Count',
                    'htn' : 'Hypertension', 'dm' : 'Diabetes Mellitus', 'cad' : 'Coronary Artery Disease', 'appet' : 'Appetite', 'pe' : 'Pedal Edema', 'ane' : 'Anemia', 'classification' : 'Class'
                 }

    df_1.rename(columns=new_names,inplace=True)

    # set up data to display in table
    
    data = df_1.to_dict('records')
    columns = [{"id": i, "name": i} for i in df_1.columns]

    return data, columns


######
# allow rows to be added to patient list 
######
@app.callback(
    dash.dependencies.Output('patient-list', 'data'),
    dash.dependencies.Input('editing-rows-button', 'n_clicks'),
    dash.dependencies.State('patient-list', 'data'),
    dash.dependencies.State('patient-list', 'columns'))
def add_row(n_clicks, rows, columns):
    if n_clicks > 0:
        rows.append({c['id']: '' for c in columns})
    return rows


######
# Set up patient list table for mobile
######
@app.callback(
    [dash.dependencies.Output('patient-list-mobile', 'data'), dash.dependencies.Output('patient-list-mobile', 'columns')],
    [dash.dependencies.Input('classification_dropdown_mobile', 'value'), dash.dependencies.Input('diabetes_dropdown_mobile', 'value')]
    )

def update_chart(classification_dropdown_mobile, diabetes_dropdown_mobile):

    # Filter summary table based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown_mobile:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown_mobile), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown_mobile:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown_mobile), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    new_names = {'id' : 'Patient ID', 'age' : 'Age', 'bp' : 'Blood Pressure', 'sg' : 'Specific Gravity', 'al' : 'Albumin', 'su' : 'Sugar', 'rbc' : 'Red Blood Cells',
                    'pc' : 'Pus Cells', 'pcc' : 'Pus Cell Clumps', 'ba' : 'Bacteria', 'bgr' : 'Blood Glucose Random', 'bu' : 'Blood Urea', 'sc' : 'Serum Creatinine',
                    'sod' : 'Sodium', 'pot' : 'Potassium', 'hemo' : 'Hemoglobin', 'pcv' : 'Packed Cell Volume', 'wc' : 'White Blood Cell Count', 'rc' : 'Red Blood Cell Count',
                    'htn' : 'Hypertension', 'dm' : 'Diabetes Mellitus', 'cad' : 'Coronary Artery Disease', 'appet' : 'Appetite', 'pe' : 'Pedal Edema', 'ane' : 'Anemia', 'classification' : 'Class'
                 }

    df_1.rename(columns=new_names,inplace=True)

    # set up data to display in table
    
    data = df_1.to_dict('records')
    columns = [{"id": i, "name": i} for i in df_1.columns]

    return data, columns

######
# allow rows to be added to patient list  mobile
######
##@app.callback(
##    dash.dependencies.Output('patient-list-mobile', 'data'),
##    dash.dependencies.Input('editing-rows-button-mobile', 'n_clicks'),
##    dash.dependencies.State('patient-list-mobile', 'data'),
##    dash.dependencies.State('patient-list-mobile', 'columns'))
##def add_row(n_clicks, rows, columns):
##    if n_clicks > 0:
##        rows.append({c['id']: '' for c in columns})
##    return rows

######
# Age Distribution
######

@app.callback(
    dash.dependencies.Output('age-distribution', 'figure'),
	[dash.dependencies.Input('classification_dropdown', 'value'), dash.dependencies.Input('diabetes_dropdown', 'value')])



def update_chart(classification_dropdown, diabetes_dropdown):

    # Filter graph based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    # Build graph
    fig = px.histogram(df_1,x='age',title="Age Distribution")
    fig.update_layout(title_x=0.5)

    return fig



######
# Age Distribution mobile
######

@app.callback(
    dash.dependencies.Output('age-distribution-mobile', 'figure'),
	[dash.dependencies.Input('classification_dropdown_mobile', 'value'), dash.dependencies.Input('diabetes_dropdown_mobile', 'value')])



def update_chart(classification_dropdown_mobile, diabetes_dropdown_mobile):

    # Filter graph based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown_mobile:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown_mobile), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown_mobile:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown_mobile), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    # Build graph
    fig = px.histogram(df_1,x='age',title="Age Distribution")
    fig.update_layout(title_x=0.5)

    return fig


####################################################################################################
# hypertension by ckd plot
####################################################################################################
@app.callback(
    dash.dependencies.Output('hypertension-by-classification', 'figure'),
	[dash.dependencies.Input('classification_dropdown', 'value'), dash.dependencies.Input('diabetes_dropdown', 'value')])


def update_chart(classification_dropdown, diabetes_dropdown):

    # Filter graph based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    # Build graph
    fig = px.histogram(df_1,x='htn',color='classification',title="Hypertension by CKD Classification").update_xaxes(categoryorder='total descending')
    fig.update_layout(title_x=0.5, xaxis_title='Hypertension')

    return fig



####################################################################################################
# hypertension by ckd plot mobile
####################################################################################################
@app.callback(
    dash.dependencies.Output('hypertension-by-classification-mobile', 'figure'),
	[dash.dependencies.Input('classification_dropdown_mobile', 'value'), dash.dependencies.Input('diabetes_dropdown_mobile', 'value')])


def update_chart(classification_dropdown_mobile, diabetes_dropdown_mobile):

    # Filter graph based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start'
    
    for i in classification_dropdown_mobile:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown_mobile), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown_mobile:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown_mobile), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    # Build graph
    fig = px.histogram(df_1,x='htn',color='classification',title="Hypertension by CKD Classification").update_xaxes(categoryorder='total descending')
    fig.update_layout(title_x=0.5, xaxis_title='Hypertension')

    return fig

####################################################################################################
# pcv vs hemo plot
####################################################################################################
@app.callback(
    dash.dependencies.Output('pcv-vs-hemo', 'figure'),
	[dash.dependencies.Input('classification_dropdown', 'value'), dash.dependencies.Input('diabetes_dropdown', 'value')])


def update_chart(classification_dropdown, diabetes_dropdown):

    # Filter graph based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown), : ].copy()
    else:
        ckd_df = ckd.copy()
    #
    for i in diabetes_dropdown:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    # Build graph
    fig = px.scatter(df_1,x='hemo',y='pcv',color='classification',title="Packed Cell Volume vs. Hemoglobin")
    fig.update_layout(title_x=0.5, xaxis_title='Hemoglobin', yaxis_title='Packed Cell Volume')

    return fig


####################################################################################################
# pcv vs hemo plot mobile
####################################################################################################
@app.callback(
    dash.dependencies.Output('pcv-vs-hemo-mobile', 'figure'),
	[dash.dependencies.Input('classification_dropdown_mobile', 'value'), dash.dependencies.Input('diabetes_dropdown_mobile', 'value')])


def update_chart(classification_dropdown_mobile, diabetes_dropdown_mobile):

    # Filter graph based on dropdown options selected
    isselect_all_l1 = 'Start' 
    isselect_all_l2 = 'Start' 
    
    for i in classification_dropdown_mobile:
        if i == 'All':
            isselect_all_l1 = 'Y'
            break
        elif i != '':
            isselect_all_l1 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l1 == 'N':
        ckd_df = ckd.loc[ckd[ckd_fields['Class']].isin(classification_dropdown_mobile), : ].copy()
    else:
        ckd_df = ckd.copy()
    
    for i in diabetes_dropdown_mobile:
        if i == 'All':
            isselect_all_l2 = 'Y'
            break
        elif i != '':
            isselect_all_l2 = 'N'
        else:
            pass
    # Filter df according to selection
    if isselect_all_l2 == 'N':
        ckd_df_2 = ckd_df.loc[ckd_df[ckd_fields['Diabetes Mellitus']].isin(diabetes_dropdown_mobile), :].copy()
    else:
        ckd_df_2 = ckd_df.copy()
    del ckd_df

    df_1 = ckd_df_2.copy()
    del ckd_df_2

    # Build graph
    fig = px.scatter(df_1,x='hemo',y='pcv',color='classification',title="Packed Cell Volume vs. Hemoglobin")
    fig.update_layout(title_x=0.5, xaxis_title='Hemoglobin', yaxis_title='Packed Cell Volume')

    return fig




#########
## for the predictive model
#########

model = joblib.load('data/TechStat_DTC_PCA.joblib')
pca_reloaded = pickle.load(open('data/TechStat_PCA_Load.pkl','rb'))
scaler = pickle.load(open('data/TechStat_StandardScaler.pkl','rb'))
#model = joblib.load('data/TechStat_DTC_NEW.joblib')

@app.callback(
    dash.dependencies.Output('model-output', component_property='children'),
    [dash.dependencies.Input('button-submit','n_clicks'),dash.dependencies.Input('sg', 'value'),dash.dependencies.Input('pcv', 'value'),
     dash.dependencies.Input('hypertension', 'value'),dash.dependencies.Input('hemo', 'value'),dash.dependencies.Input('diabetes', 'value')]
    )

def update_ckd_risk(n_clicks,sg,pcv,hypertension,hemo,diabetes):
    if sg is not None and sg != '' and pcv is not None and pcv != '' and hypertension is not None and hypertension != '' and hemo is not None and hemo != '' and diabetes is not None and diabetes != '':
        input_values = [sg, pcv, hypertension, hemo, diabetes]
        input_df = pd.DataFrame([input_values])
        scaled_input = scaler.transform(input_df)
        pca_data = pca_reloaded.transform(scaled_input)

        changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
        if 'button-submit' in changed_id:
        #if n_clicks >0:
            try:
                ckd_class = int(model.predict(pca_data))
                if ckd_class == 1:
                    return 'The values you have entered indicate that you are at a higher risk level for developing Chronic Kidney Disease.\n \
                            It is strongly recommended that you consult with your primary care physician about this during your next visit.\n \
                            \n \
                            DISCLAIMER: This predictive application is not a substitute for consultation with your physician, and in no\n \
                                        way constitutes a definitive medical diagnosis by a licensed medical doctor.'
                elif ckd_class == 0:
                    return 'The values you have entered indicate that your risk level for developing Chronic Kidney Disease is within the normal range.\n \
                            Continue to practice healthy habits, and consult with your primary care physician regarding minimizing your risk for developing Chronic Kidney Disease.\n \
                            \n \
                            DISCLAIMER: This predictive application is not a substitute for consultation with your physician, and in no\n \
                                    way constitutes a definitive medical diagnosis by a licensed medical doctor.'
                else:
                    return ''
            except ValueError:
                return 'Unable to Process Input. Please Input Valid Information.'
