# Local Python Instructions

Note: you must have a python installation or virtual environment to follow this guide. Python 3.9 was used in development.

1. Download the entire folder to a location on your local computer
2. Open the folder
3. From the TechStat_Dasbhoard directory, run the index.py file
    - You can double click on the file to execute
    - You can right click on the file and open with your chosen IDE, and execute from here
    - You can navigate to the directory in command prompt/powershell/terminal and run with python, i.e. python index.py
5. Once this executes, you should start seeing some log output in your window, like the below:
    > Dash is running on http://127.0.0.1:8050/
6. Open a browser, and navigate to http://127.0.0.1:8050/ in the navigation bar
7. You will now see the application, and can access it normally

To log into the provider page, the user/password is as follows:
    User: dr_jones
    Password: techstat_dashboard