import plotly.graph_objs as go
import pandas as pd
import numpy as np
import dash
from dash import dcc, html, dash_table
import dash_bootstrap_components as dbc
from dash.dash_table.Format import Format, Group, Scheme
from dash.dash_table import FormatTemplate as FormatTemplate
from datetime import datetime as dt
from app import app

#####
# Formatting for colors and stuff
#####

techstat_colors = {
    'dark-blue-grey' : 'rgb(62, 64, 76)',
    'medium-blue' : 'rgb(51, 133, 255)',
    'superdark-blue' : 'rgb(0, 31, 77)',
    'dark-blue' : 'rgb(0, 51, 128)',
    'medium-green' : 'rgb(93, 113, 120)',
    'light-blue' : 'rgb(153, 194, 255)',
    'pink-red' : 'rgb(255, 101, 131)',
    'dark-pink-red' : 'rgb(247, 80, 99)',
    'white' : 'rgb(251, 251, 252)',
    'light-grey' : 'rgb(208, 206, 206)'
}

externalgraph_rowstyling = {
    #'margin-left' : '15px',
    #'margin-right' : '15px',
    'background-color' : techstat_colors['dark-blue']
}

externalgraph_colstyling = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : techstat_colors['superdark-blue'],
    'background-color' : techstat_colors['superdark-blue'],
    'box-shadow' : '0px 0px 17px 0px rgba(186, 218, 212, .5)',
    'padding-top' : '10px'
}

filterdiv_borderstyling = {
    'border-radius' : '0px 0px 10px 10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : techstat_colors['light-blue'],
    'background-color' : techstat_colors['light-blue'],
    'box-shadow' : '2px 5px 5px 1px rgba(255, 101, 131, .5)'
    }

navbarcurrentpage = {
    'text-decoration' : 'underline',
    'text-decoration-color' : techstat_colors['pink-red'],
    'text-shadow': '0px 0px 1px rgb(251, 251, 252)'
    }

recapdiv = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : 'rgb(251, 251, 252, 0.1)',
    'margin-left' : '15px',
    'margin-right' : '15px',
    'margin-top' : '15px',
    'margin-bottom' : '15px',
    'padding-top' : '5px',
    'padding-bottom' : '5px',
    'background-color' : 'rgb(251, 251, 252, 0.1)'
    }

patientdiv = {
    'border-radius' : '10px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : 'rgb(251, 251, 252, 0.1)',
    'margin-left' : '15px',
    'margin-right' : '15px',
    'margin-top' : '15px',
    'margin-bottom' : '15px',
    'padding-top' : '5px',
    'padding-bottom' : '5px',
    'background-color' : 'rgb(153, 194, 255, 0.9)'
    }

imgdiv = {
    'border-radius' : '5px',
    'border-style' : 'solid',
    'border-width' : '1px',
    'border-color' : 'rgb(251, 251, 252, 0.1)',
    'margin-left' : '10px',
    'margin-right' : '10px',
    'margin-top' : '10px',
    'margin-bottom' : '10px',
    'padding-top' : '5px',
    'padding-bottom' : '5px',
    'background-color' : 'rgb(251, 251, 252, 0.1)'
    }

recapdiv_text = {
    'text-align' : 'left',
    'font-weight' : '350',
    'color' : techstat_colors['white'],
    'font-size' : '1.5rem',
    'letter-spacing' : '0.04em'
    }

techstat_font_family = 'Dosis'


######
# Mapping input data
#####

#map field names in data source to more readable names
ckd_filepath = 'data/CKD_CLEANED.csv'

ckd_fields = {
    'ID' : 'id',
    'Age' : 'age',
    'Blood Pressure' : 'bp',
    'Specific Gravity' : 'sg',
    'Albumin' : 'al',
    'Sugar' : 'su',
    'Red Blood Cells' : 'rbc',
    'Pus Cells' : 'pc',
    'Pus Cell Clumps' : 'pcc',
    'Bacteria' : 'ba',
    'Blood Glucose Random' : 'bgr',
    'Blood Urea' : 'bu',
    'Serum Creatinine' : 'sc',
    'Sodium' : 'sod',
    'Potassium' : 'pot',
    'Hemoglobin' : 'hemo',
    'Packed Cell Volume' : 'pcv',
    'White Blood Cell Count' : 'wc',
    'Red Blood Cell Count' : 'rc',
    'Hypertension' : 'htn',
    'Diabetes Mellitus' : 'dm',
    'Coronary Artery Disease' : 'cad',     
    'Appetite' : 'appet',
    'Pedal Edema' : 'pe',
    'Anemia' : 'ane',
    'Class' : 'classification'
    }


######
# Import the data set(s)
######

#Import ckd data into dataframe
ckd = pd.read_csv(ckd_filepath)
# strip all whitespace from cells
ckd = ckd.apply(lambda x: x.str.strip() if x.dtype == "object" else x)


# Dropdown options for classification pick list
classification_l1 = ckd[ckd_fields['Class']].unique()
classification_l1_all_2 = [
    {'label' : k, 'value' : k} for k in sorted(classification_l1)
    ]
classification_l1_all_1 = [{'label' : '(Select All)', 'value' : 'All'}]
classification_l1_all = classification_l1_all_1 + classification_l1_all_2

# Dropdown options for diabetes pick list, just as an example
diabetes_groups_l2 = ckd[ckd_fields['Diabetes Mellitus']].unique()
diabetes_groups_l2_all_2 = [
    {'label' : k, 'value' : k} for k in diabetes_groups_l2
    ]
diabetes_groups_l2_all_1 = [{'label' : '(Select All)', 'value' : 'All'}]
diabetes_groups_l2_all = diabetes_groups_l2_all_1 + diabetes_groups_l2_all_2

# to cascade if multiple filters are selected
both_groups_l1_l2 = {}
for l1 in classification_l1:
    l2 = ckd[ckd[ckd_fields['Class']] == l1][ckd_fields['Diabetes Mellitus']].unique()
    both_groups_l1_l2[l1] = l2


# Dropdown options for classification pick list mobile
classification_l1_mobile = ckd[ckd_fields['Class']].unique()
classification_l1_all_2_mobile = [
    {'label' : k, 'value' : k} for k in sorted(classification_l1_mobile)
    ]
classification_l1_all_1_mobile = [{'label' : '(Select All)', 'value' : 'All'}]
classification_l1_all_mobile = classification_l1_all_1_mobile + classification_l1_all_2_mobile

# Dropdown options for diabetes pick list, just as an example
diabetes_groups_l2_mobile = ckd[ckd_fields['Diabetes Mellitus']].unique()
diabetes_groups_l2_all_2_mobile = [
    {'label' : k, 'value' : k} for k in diabetes_groups_l2_mobile
    ]
diabetes_groups_l2_all_1_mobile = [{'label' : '(Select All)', 'value' : 'All'}]
diabetes_groups_l2_all_mobile = diabetes_groups_l2_all_1_mobile + diabetes_groups_l2_all_2_mobile

# to cascade if multiple filters are selected
both_groups_l1_l2_mobile = {}
for l1_mobile in classification_l1_mobile:
    l2_mobile = ckd[ckd[ckd_fields['Class']] == l1_mobile][ckd_fields['Diabetes Mellitus']].unique()
    both_groups_l1_l2_mobile[l1] = l2_mobile

######
# Helper functions
#####

# Header with logo
def get_header():

    header = html.Div([

        html.Div([], className = 'col-2'), 

        html.Div([
            html.H1(children='Chronic Kidney Disease',
                    style = {'textAlign' : 'center'}
            )],
            className='col-8',
            style = {'padding-top' : '1%'}
        ),

        html.Div([
            html.Img(
                    src = app.get_asset_url('techstat_logo.png'),
                    height = '60 px',
                    width = 'auto')
            ],
            className = 'col-2',
            style = {
                    'align-items': 'center',
                    'padding-top' : '1%',
                    'height' : 'auto'})

        ],
        className = 'row',
        style = {'height' : '4%',
                'background-color' : techstat_colors['superdark-blue']}
        )

    return header

#####################
# Nav bar
def get_navbar(p = 'prediction_page'):

    navbar_predictions = html.Div([

        html.Div([], className = 'col-3'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Predictions',
                        style = navbarcurrentpage),
                href='/apps/predictions'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Provider Overview'),
                href='/apps/provider'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Information'),
                href='/apps/overview'
                )
        ],
        className='col-2'),

        html.Div([], className = 'col-3')

    ],
    className = 'row',
    style = {'background-color' : techstat_colors['dark-blue'],
            'box-shadow': '2px 5px 5px 1px rgba(255, 101, 131, .5)'}
    )

    navbar_provider = html.Div([

        html.Div([], className = 'col-3'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Predictions'),
                href='/apps/predictions'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Provider Overview',
                        style = navbarcurrentpage),
                href='/apps/provider'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Information'),
                href='/apps/overview'
                )
        ],
        className='col-2'),

        html.Div([], className = 'col-3')

    ],
    className = 'row',
    style = {'background-color' : techstat_colors['dark-blue'],
            'box-shadow': '2px 5px 5px 1px rgba(255, 101, 131, .5)'}
    )

    navbar_information = html.Div([

        html.Div([], className = 'col-3'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Predictions'),
                href='/apps/predictions'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Provider Overview'),
                href='/apps/provider'
                )
        ],
        className='col-2'),

        html.Div([
            dcc.Link(
                html.H4(children = 'Information',
                        style = navbarcurrentpage),
                href='/apps/overview'
                )
        ],
        className='col-2'),

        html.Div([], className = 'col-3')

    ],
    className = 'row',
    style = {'background-color' : techstat_colors['dark-blue'],
            'box-shadow': '2px 5px 5px 1px rgba(255, 101, 131, .5)'}
    )

    if p == 'information_page':
        return navbar_information
    elif p == 'prediction_page':
        return navbar_predictions
    else:
        return navbar_provider

#####################
# Empty row

def get_emptyrow(h='45px'):
    
    emptyrow = html.Div([
        html.Div([
            html.Br()
        ], className = 'col-12')
    ],
    className = 'row',
    style = {'height' : h, 'background-color' : techstat_colors['dark-blue']})

    return emptyrow

def prediction_form():
    markdown = ''' # Input Values to Determine CKD Risk'''   
    form = html.Div([ dbc.Container([
            dcc.Markdown(markdown)
            , html.Br()
            , dbc.Card(
                dbc.CardBody([
                     dbc.Form([sg_input,
                               hemo_input,
                               pcv_input,
                               htn_input,
                               diabetes_input])
                ,html.Div(id = 'div-button', children = [
                    dbc.Button('Submit'
                    , color = 'primary'
                    , id='button-submit'
                    , n_clicks=0)
                ]) #end div
                ])#end cardbody
            )#end card
            , html.Br()
            , html.Br()
        ])
        ],style={'background-color' : techstat_colors['dark-blue']})
    
    return form

def prediction_form_mobile():
    markdown = ''' # Input Values to Determine CKD Risk'''   
    form = html.Div([ dbc.Container([
            dcc.Markdown(markdown)
            , html.Br()
            , dbc.Card(
                dbc.CardBody([
                     dbc.Form([sg_input_mobile,
                               hemo_input_mobile,
                               pcv_input_mobile,
                               htn_input_mobile,
                               diabetes_input_mobile])
                ,html.Div(id = 'div-button', children = [
                    dbc.Button('Submit'
                    , color = 'primary'
                    , id='button-submit'
                    , n_clicks=0)
                ]) #end div
                ])#end cardbody
            )#end card
            , html.Br()
            , html.Br()
        ])
        ],style={'background-color' : techstat_colors['dark-blue']})
    
    return form

#####
# Provider page setup
#####

provider_page = html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_navbar('provider_page'),

    #####################
    #Row 3 : Filters
    html.Div([ # External row

        html.Div([ # External 12-column

            html.Div([ # Internal row

                #Internal columns
                html.Div([
                ],
                className = 'col-2'), # Blank 2 columns

                #Filter pt 2
                html.Div([

                    html.Div([
                        html.H5(
                            children='Filters:',
                            style = {'text-align' : 'left', 'color' : techstat_colors['dark-blue']}
                        ),
                        #Reporting group selection l1
                        html.Div([
                            dcc.Dropdown(id = 'classification_dropdown',
                                options = classification_l1_all,
                                value = [''],
                                multi = True,
                                placeholder = "Select " +ckd_fields['Class']+ " (leave blank to include all)",
                                style = {'font-size': '13px', 'color' : techstat_colors['medium-blue'], 'white-space': 'nowrap', 'text-overflow': 'ellipsis'}
                                )
                            ],
                            style = {'width' : '70%', 'margin-top' : '5px'}),
                        #Reporting group selection l2
                        html.Div([
                            dcc.Dropdown(id = 'diabetes_dropdown',
                                options = diabetes_groups_l2_all,
                                value = [''],
                                multi = True,
                                placeholder = "Select " +ckd_fields['Diabetes Mellitus']+ " (leave blank to include all)",
                                style = {'font-size': '13px', 'color' : techstat_colors['medium-blue'], 'white-space': 'nowrap', 'text-overflow': 'ellipsis'}
                                )
                            ],
                            style = {'width' : '70%', 'margin-top' : '5px'})
                    ],
                    style = {'margin-top' : '10px',
                            'margin-bottom' : '5px',
                            'text-align' : 'left',
                            'paddingLeft': 5})

                ],
                className = 'col-4'), # Filter part 2

                html.Div([
                ],
                className = 'col-2') # Blank 2 columns


            ],
            className = 'row') # Internal row

        ],
        className = 'col-12',
        style = filterdiv_borderstyling) # External 12-column

    ],
    className = 'row sticky-top'), # External row

    #####################
    #Row 4
    get_emptyrow(),

    #####################
    #Row 5 : Charts
    html.Div([ # External row

        html.Div([
        ],
        className = 'col-1', style={'background-color' : techstat_colors['dark-blue']}), # Blank 1 column

        html.Div([ # External 10-column

            html.H2(children = "Patient Summary",
                    style = {'color' : techstat_colors['white']}),

            html.Div([ # Internal row - summary table

                html.Div([],className = 'col-4'), # Empty column

                html.Div([
                    dash_table.DataTable(
                        id='recap-table',
                        style_header = {
                            'backgroundColor': 'transparent',
                            'fontFamily' : techstat_font_family,
                            'font-size' : '1rem',
                            'color' : techstat_colors['light-blue'],
                            'border': '0px transparent',
                            'textAlign' : 'center'},
                        style_cell = {
                            'backgroundColor': 'transparent',
                            'fontFamily' : techstat_font_family,
                            'font-size' : '0.85rem',
                            'color' : techstat_colors['white'],
                            'border': '0px transparent',
                            'textAlign' : 'center'},
                        cell_selectable = False,
                        column_selectable = False
                    )
                ],
                className = 'col-4'),

                html.Div([],className = 'col-4') # Empty column

            ],
            className = 'row',
            style = recapdiv
            ),# Internal row - summary table

            html.H2(children = "Patient List",
                    style = {'color' : techstat_colors['white']}),

            html.Div([ # Internal row - patient list

            

                html.Div([
                    dash_table.DataTable(
                        id='patient-list',
                        style_header = {
                            'backgroundColor': 'black',
                            'fontFamily' : techstat_font_family,
                            'font-size' : '.9rem',
                            'fontWeight': 'bold',
                            'color' : techstat_colors['light-blue'],
                            #'border': '0px transparent',
                            'textAlign' : 'center'},
                        style_cell = {
                            'backgroundColor': 'black',
                            'fontFamily' : techstat_font_family,
                            'font-size' : '0.85rem',
                            'color' : techstat_colors['white'],
                            'minWidth': '100px',
                            'width': '100px',
                            'maxWidth': '180px',
                            'textAlign' : 'center'},
                        fixed_columns={'headers': True, 'data': 1},
                        style_table={'overflowX': 'auto','minWidth':'100%'},
                        #cell_selectable = False,
                        sort_action='native',
                        sort_mode='multi',
                        column_selectable = False,
                        page_size=10,
                        editable=True,
                        row_deletable=True,
                        export_format='xlsx',
                        css=[{ 'selector': '.previous-page, .next-page', 'rule': 'background-color: white;' }],
                    ),
                    html.Button('Add Row', id='editing-rows-button', n_clicks=0),
                ],
                className = 'col-12'
                )
            ],
            className = 'row',
            style = patientdiv
            ),# Internal row - patient list

            html.Div([ # Internal row

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='age-distribution')
                ],
                className = 'col-4'),

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='hypertension-by-classification')
                ],
                className = 'col-4'),

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='pcv-vs-hemo')
                ],
                className = 'col-4')

            ],
            className = 'row'), # Internal row

        ],
        className = 'col-10',
        style = externalgraph_colstyling), # External 10-column

        html.Div([
        ],
        className = 'col-1', style={'background-color' : techstat_colors['dark-blue']}), # Blank 1 column

    ],
    className = 'row',
    style = externalgraph_rowstyling
    ), # External row

])

#####
# Prediction page setup inputs
#####

sg_input = dbc.Row([
        dbc.Label("Specific Gravity"
                , html_for="sg"
                , width=2),
        dbc.Col(dbc.Input(
                type="number"
                , id="sg"
                , placeholder="Enter Specific Gravity"
            ),width=10,
        )],className="mb-3"
)


hemo_input = dbc.Row([
        dbc.Label("Hemoglobin"
                , html_for="hemo"
                , width=2),
        dbc.Col(dbc.Input(
                type="number"
                , id="hemo"
                , placeholder="Enter Hemoglobin (gms)"
            ),width=10,
        )],className="mb-3"
)

pcv_input = dbc.Row([
        dbc.Label("Packed Cell Volume"
                , html_for="pcv"
                , width=2),
        dbc.Col(dbc.Input(
                type="number"
                , id="pcv"
                , placeholder="Enter Packed Cell Volume"
            ),width=10,
        )],className="mb-3"
)

htn_input = dbc.Row([
        dbc.Label("Hypertension", html_for="hypertension", width=2)
        ,dbc.Col(
            dcc.Dropdown(
                options=[{"label": "Yes", "value": "1"},
                         {"label": "No", "value": "0"}]
                , id = "hypertension"
                , className="mb-3"
                , placeholder="Do You Have Hypertension?"
                )
            , width=10)
        ], className="mb-3")
##
diabetes_input = dbc.Row([
        dbc.Label("Diabetes", html_for="diabetes", width=2),
        dbc.Col(
            dcc.Dropdown(
                options=[{"label": "Yes", "value": "1"},
                         {"label": "No", "value": "0"}]
                , id="diabetes"
                , placeholder="Do You Have Diabetes?"
            ),width=10
        )], className="mb-3"
)





#####
# Prediction page setup
#####

prediction_page = html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_navbar('prediction_page'),

    #####################
    #Row 3 : Filters
    html.Div([ # External row

        html.Br(style={'background-color' : techstat_colors['dark-blue']})

    ],
    className = 'row sticky-top'), # External row

    #####################
    #Row 4
    get_emptyrow(),

    #####################
    #Row 5 : User Input
    html.Div([ # External row

        prediction_form()

    ]),

    #####################
    #Row 6
    get_emptyrow(),

    #####################
    #Output from model
    html.Div([
        html.H3(
        id='model-output',
        style={'font-weight':'bold'}),
        ],
        style = recapdiv
    ),

])

#####
# info page setup
#####

information_page = html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_navbar('information_page'),

    #####################
    #Row 3 : Filters
    html.Div([ # External row

        html.Br()

    ],
    className = 'row sticky-top'), # External row

    #####################
    #Row 4
    #get_emptyrow(),

    #####################
    #Row 5 : Charts
    html.Div([# External row
    html.Div([ #first row of links and problem statement
        
        html.Div([ #links section
            #html.Div([],className = 'col-1'), # Blank 1 column
            html.H4(children='Helpful Links', className = "gs-header gs-text-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
            #html.Strong('Helpful Links',style = {'color' : techstat_colors['white'],'textAlign' : 'center'}),
            #html.Br(),
            html.Li(html.A('Chronic Kidney Disease Basics',href='https://www.cdc.gov/kidneydisease/basics.html',style = {'color' : techstat_colors['white']}),style = {'color' : techstat_colors['white']}),
            #html.Br(),
            html.Li(html.A('CKD Prevalence in Medicare Beneficiaries 65 and Older',href='https://nccd.cdc.gov/ckd/detail.aspx?QNum=Q705',style = {'color' : techstat_colors['white']}),style = {'color' : techstat_colors['white']}),
            #html.Br(),
            html.Li(html.A('2022 US Renal Data System Annual Report',href='https://usrds-adr.niddk.nih.gov/2022',style = {'color' : techstat_colors['white']}),style = {'color' : techstat_colors['white']}),
            #html.Br(),
            html.Li(html.A('Kidney Disease Mortality by State',href='https://www.cdc.gov/nchs/pressroom/sosmap/kidney_disease_mortality/kidney_disease.htm',style = {'color' : techstat_colors['white']}),style = {'color' : techstat_colors['white']})
            ], className = "col-3", style=recapdiv),#end links section

    #], className='col-4', style=recapdiv), #end links container
    #html.Div([
        html.Div([ #problem statement section
                    html.H4("Problem Statement",
                            className = "gs-header gs-table-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
                    html.P(['According to the United States Centers for Disease Control and Prevention (CDC), there are approximately 37 million adults in the US \
                            (15% of the adult population) who have chronic kidney disease (CKD), but 9 out of 10 of those adults are not aware that they have CKD.',
                            html.Br(),
                            html.Br(),
                            'If left untreated, CKD eventually turns into kidney failure, also known as end-stage renal disease (ESRD). By this point dialysis or \
                            kidney transplant are needed for the person to survive. It is not possible to reverse damage already done to kidneys, but if caught \
                            earlier, steps can be implemented to slow the progression of CKD.'], style = {'color' : techstat_colors['white'],'font-size' : '1.25rem'})
                ], className = "col-8", style=patientdiv),

    ],style={"display": "flex"} ), #end first row

    html.Div([#second row financial impact
        
        html.Div([ #financial impact section
                    html.H4("Financial Impact",
                            className = "gs-header gs-table-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
                    html.P(['Chronic Kidney Disease not only impacts people’s health and livelihood individually, but the collective economic burden of CKD on \
                             the US healthcare system is substantial. According to data on Medicare spending in 2020, the average cost per patient per year was \
                             2.6x more for patients with CKD and 8.8x more for patients with ESRD when compared to patients without CKD or ESRD.',
                            html.Br(),
                            html.Br(),
                            'In 2020, 13.9% of Medicare fee-for-service patients aged 66 or older were diagnosed with CKD, and this group accounted for about 25%\
                             of total Medicare fee for service spending (or $75 Billion). In addition, Medicare fee for service spending for patients of all ages \
                             diagnosed with CKD accounted for 23.5% of total Medicare fee for service spending (or $85.4 Billion).',
                            html.Br(),
                            html.Br(),
                            'Implementation of early detection and prevention of CKD has the potential to save Medicare up to $53 Billion per year based on costs \
                             per patient per year and total spending on CKD in 2020.'], style = {'color' : techstat_colors['white'],'font-size' : '1.25rem'})
                ], className = "col-12", style=recapdiv),
        ], className='row'), # end second row

    html.Div([#third row row air contaminants
        #html.Div([],className = 'col-1'), # Blank 1 column
        html.Div([ #air contaminants section
                    html.H5("Air Contaminants",
                            className = "gs-header gs-table-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
                    html.Img(src=app.get_asset_url('CKD_Air_Contaminants.png'), alt='CKD Prevalence in Senior Citizens by County, with Air Contaminants', style={'height': '95%', 'width': '100%'}),
                    #html.Br(),
                    #html.Br()
                ], className = "col-6", style=imgdiv),
        #html.Div([],className = 'col-1'), # Blank 1 column
        html.Div([ #water contaminants section
                    html.H5("Water Contaminants",
                            className = "gs-header gs-table-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
                    html.Img(src=app.get_asset_url('CKD_Water_Contaminants.png'), alt='CKD Prevalence in Senior Citizens by County, with Water Contaminants', style={'height': '95%', 'width': '100%'}),
                    #html.Br(),
                    #html.Br()
                ], className = "col-6", style=imgdiv),
        ], style={"display": "flex",'maxWidth':'97%'}),
        #html.Div([],className = 'col-1'), # Blank 1 column
        html.Br(),
        html.Br()

], className = 'row'),
    ],style={'background-color' : techstat_colors['superdark-blue']})



#####
# info page setup for mobile
#####

information_page_mobile = html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_emptyrow(),

    #####################
    #Row 3 : Filters
    html.Div([ # External row

        html.Br()

    ],
    className = 'row sticky-top'), # External row

    #####################
    #Row 4
    #get_emptyrow(),

    #####################
    #Row 5 : Charts
    html.Div([# External row
    html.Div([ #first row problem statement
                html.Div([ #problem statement section
                    html.H4("Problem Statement",
                            className = "gs-header gs-table-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
                    html.P(['According to the United States Centers for Disease Control and Prevention (CDC), there are approximately 37 million adults in the US \
                            (15% of the adult population) who have chronic kidney disease (CKD), but 9 out of 10 of those adults are not aware that they have CKD.',
                            html.Br(),
                            html.Br(),
                            'If left untreated, CKD eventually turns into kidney failure, also known as end-stage renal disease (ESRD). By this point dialysis or \
                            kidney transplant are needed for the person to survive. It is not possible to reverse damage already done to kidneys, but if caught \
                            earlier, steps can be implemented to slow the progression of CKD.'], style = {'color' : techstat_colors['white'],'font-size' : '1.25rem'})
                ], className = "col-12", style=patientdiv),

    ],style={"display": "flex"} ), #end first row

    html.Div([ #second row of links
        
        html.Div([ #links section
            #html.Div([],className = 'col-1'), # Blank 1 column
            html.H4(children='Helpful Links', className = "gs-header gs-text-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
            #html.Strong('Helpful Links',style = {'color' : techstat_colors['white'],'textAlign' : 'center'}),
            #html.Br(),
            html.Li(html.A('Chronic Kidney Disease Basics',href='https://www.cdc.gov/kidneydisease/basics.html',style = {'color' : techstat_colors['white']}),style = {'color' : techstat_colors['white']}),
            #html.Br(),
            html.Li(html.A('CKD Prevalence in Medicare Beneficiaries 65 and Older',href='https://nccd.cdc.gov/ckd/detail.aspx?QNum=Q705',style = {'color' : techstat_colors['white']}),style = {'color' : techstat_colors['white']}),
            #html.Br(),
            html.Li(html.A('2022 US Renal Data System Annual Report',href='https://usrds-adr.niddk.nih.gov/2022',style = {'color' : techstat_colors['white']}),style = {'color' : techstat_colors['white']}),
            #html.Br(),
            html.Li(html.A('Kidney Disease Mortality by State',href='https://www.cdc.gov/nchs/pressroom/sosmap/kidney_disease_mortality/kidney_disease.htm',style = {'color' : techstat_colors['white']}),style = {'color' : techstat_colors['white']})
            ], className = "col-12", style=recapdiv)#end links section

    ],style={"display": "flex"} ), #end second row

    html.Div([#third row financial impact
        
        html.Div([ #financial impact section
                    html.H4("Financial Impact",
                            className = "gs-header gs-table-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
                    html.P(['Chronic Kidney Disease not only impacts people’s health and livelihood individually, but the collective economic burden of CKD on \
                             the US healthcare system is substantial. According to data on Medicare spending in 2020, the average cost per patient per year was \
                             2.6x more for patients with CKD and 8.8x more for patients with ESRD when compared to patients without CKD or ESRD.',
                            html.Br(),
                            html.Br(),
                            'In 2020, 13.9% of Medicare fee-for-service patients aged 66 or older were diagnosed with CKD, and this group accounted for about 25%\
                             of total Medicare fee for service spending (or $75 Billion). In addition, Medicare fee for service spending for patients of all ages \
                             diagnosed with CKD accounted for 23.5% of total Medicare fee for service spending (or $85.4 Billion).',
                            html.Br(),
                            html.Br(),
                            'Implementation of early detection and prevention of CKD has the potential to save Medicare up to $53 Billion per year based on costs \
                             per patient per year and total spending on CKD in 2020.'], style = {'color' : techstat_colors['white'],'font-size' : '1.25rem'})
                ], className = "col-12", style=recapdiv),
        ], className='row'), # end third row

    html.Div([#fourth row row air contaminants
        #html.Div([],className = 'col-1'), # Blank 1 column
        html.Div([ #air contaminants section
                    html.H5("Air Contaminants",
                            className = "gs-header gs-table-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
                    html.Img(src=app.get_asset_url('CKD_Air_Contaminants.png'), alt='CKD Prevalence in Senior Citizens by County, with Air Contaminants', style={'height': '95%', 'width': '100%'}),
                    #html.Br(),
                    #html.Br()
                ], className = "row", style=imgdiv),
        ], className = 'row'),


    html.Div([#fifth row water contaminants
        #html.Div([],className = 'col-1'), # Blank 1 column
        html.Div([ #water contaminants section
                    html.H5("Water Contaminants",
                            className = "gs-header gs-table-header padded",style = {'color' : techstat_colors['white'],'fontWeight' : 'bold'}),
                    html.Img(src=app.get_asset_url('CKD_Water_Contaminants.png'), alt='CKD Prevalence in Senior Citizens by County, with Water Contaminants', style={'height': '95%', 'width': '100%'}),
                    #html.Br(),
                    #html.Br()
                ], className = "row", style=imgdiv),
        ], className = 'row'),
        #html.Div([],className = 'col-1'), # Blank 1 column
        html.Br(),
        html.Br()

], className = 'row'),
    ],style={'background-color' : techstat_colors['superdark-blue']})


#####
# Prediction page setup inputs for mobile
#####

sg_input_mobile = dbc.Row([
        dbc.Label("Specific Gravity"
                , html_for="sg"
                , width=4),
        dbc.Col(dbc.Input(
                type="number"
                , id="sg"
                , placeholder="Enter Specific Gravity"
            ),width=8,
        )],className="mb-3"
)


hemo_input_mobile = dbc.Row([
        dbc.Label("Hemoglobin"
                , html_for="hemo"
                , width=4),
        dbc.Col(dbc.Input(
                type="number"
                , id="hemo"
                , placeholder="Enter Hemoglobin (gms)"
            ),width=8,
        )],className="mb-3"
)

pcv_input_mobile = dbc.Row([
        dbc.Label("Packed Cell Volume"
                , html_for="pcv"
                , width=4),
        dbc.Col(dbc.Input(
                type="number"
                , id="pcv"
                , placeholder="Enter Packed Cell Volume"
            ),width=8,
        )],className="mb-3"
)

htn_input_mobile = dbc.Row([
        dbc.Label("Hypertension", html_for="hypertension", width=4)
        ,dbc.Col(
            dcc.Dropdown(
                options=[{"label": "Yes", "value": "1"},
                         {"label": "No", "value": "0"}]
                , id = "hypertension"
                , className="mb-3"
                , placeholder="Do You Have Hypertension?"
                )
            , width=8)
        ], className="mb-3")
##
diabetes_input_mobile = dbc.Row([
        dbc.Label("Diabetes", html_for="diabetes", width=4),
        dbc.Col(
            dcc.Dropdown(
                options=[{"label": "Yes", "value": "1"},
                         {"label": "No", "value": "0"}]
                , id="diabetes"
                , placeholder="Do You Have Diabetes?"
            ),width=8
        )], className="mb-3"
)

#####
# Prediction page setup for mobile
#####

prediction_page_mobile= html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_emptyrow(),

    #####################
    #Row 3 : Filters
    html.Div([ # External row

        html.Br(style={'background-color' : techstat_colors['dark-blue']})

    ],
    className = 'row sticky-top'), # External row

    #####################
    #Row 4
    #get_emptyrow(),

    #####################
    #Row 5 : User Input
    html.Div([ # External row

        prediction_form_mobile()

    ]),

    #####################
    #Row 6
    get_emptyrow(),

    #####################
    #Output from model
    html.Div([
        html.H3(
        id='model-output',
        style={'font-weight':'bold'}),
        ],
        style = recapdiv
    ),

], style={'background-color' : techstat_colors['dark-blue']})

#####
# Provider page setup for mobile
#####

provider_page_mobile = html.Div([

    #####################
    #Row 1 : Header
    get_header(),

    #####################
    #Row 2 : Nav bar
    get_emptyrow(),

    #####################
    #Row 3 : Filters
    html.Div([ # External row

        html.Div([ # External 12-column

            html.Div([ # Internal row

                #Internal columns
                html.Div([
                ],
                className = 'col-2'), # Blank 2 columns

                #Filter pt 2
                html.Div([

                    html.Div([
                        html.H5(
                            children='Filters:',
                            style = {'text-align' : 'left', 'color' : techstat_colors['dark-blue']}
                        ),
                        #Reporting group selection l1
                        html.Div([
                            dcc.Dropdown(id = 'classification_dropdown_mobile',
                                options = classification_l1_all_mobile,
                                value = [''],
                                multi = True,
                                placeholder = "Select " +ckd_fields['Class']+ " (leave blank to include all)",
                                style = {'font-size': '13px', 'color' : techstat_colors['medium-blue'], 'white-space': 'nowrap', 'text-overflow': 'ellipsis'}
                                )
                            ],
                            style = {'width' : '70%', 'margin-top' : '5px'}),
                        #Reporting group selection l2
                        html.Div([
                            dcc.Dropdown(id = 'diabetes_dropdown_mobile',
                                options = diabetes_groups_l2_all_mobile,
                                value = [''],
                                multi = True,
                                placeholder = "Select " +ckd_fields['Diabetes Mellitus']+ " (leave blank to include all)",
                                style = {'font-size': '13px', 'color' : techstat_colors['medium-blue'], 'white-space': 'nowrap', 'text-overflow': 'ellipsis'}
                                )
                            ],
                            style = {'width' : '70%', 'margin-top' : '5px'})
                    ],
                    style = {'margin-top' : '10px',
                            'margin-bottom' : '5px',
                            'text-align' : 'left',
                            'paddingLeft': 5})

                ],
                className = 'col-4'), # Filter part 2

                html.Div([
                ],
                className = 'col-2') # Blank 2 columns


            ],
            className = 'row') # Internal row

        ],
        className = 'col-12',
        style = filterdiv_borderstyling) # External 12-column

    ],
    className = 'row sticky-top'), # External row

    #####################
    #Row 4
    get_emptyrow(),

    #####################
    #Row 5 : Charts
    html.Div([ # External row

        html.Div([
        ],
        className = 'col-1', style={'background-color' : techstat_colors['dark-blue']}), # Blank 1 column

        html.Div([ # External 10-column

            html.H2(children = "Patient Summary",
                    style = {'color' : techstat_colors['white']}),

            html.Div([ # Internal row - summary table

                html.Div([],className = 'col-4'), # Empty column

                html.Div([
                    dash_table.DataTable(
                        id='recap-table-mobile',
                        style_header = {
                            'backgroundColor': 'transparent',
                            'fontFamily' : techstat_font_family,
                            'font-size' : '1rem',
                            'color' : techstat_colors['light-blue'],
                            'border': '0px transparent',
                            'textAlign' : 'center'},
                        style_cell = {
                            'backgroundColor': 'transparent',
                            'fontFamily' : techstat_font_family,
                            'font-size' : '0.85rem',
                            'color' : techstat_colors['white'],
                            'border': '0px transparent',
                            'textAlign' : 'center'},
                        cell_selectable = False,
                        column_selectable = False
                    )
                ],
                className = 'col-4'),

                html.Div([],className = 'col-4') # Empty column

            ],
            className = 'row',
            style = recapdiv
            ),# Internal row - summary table

            html.H2(children = "Patient List",
                    style = {'color' : techstat_colors['white']}),

            html.Div([ # Internal row - patient list

            

                html.Div([
                    dash_table.DataTable(
                        id='patient-list-mobile',
                        style_header = {
                            'backgroundColor': 'black',
                            'fontFamily' : techstat_font_family,
                            'font-size' : '.9rem',
                            'fontWeight': 'bold',
                            'color' : techstat_colors['light-blue'],
                            #'border': '0px transparent',
                            'textAlign' : 'center'},
                        style_cell = {
                            'backgroundColor': 'black',
                            'fontFamily' : techstat_font_family,
                            'font-size' : '0.85rem',
                            'color' : techstat_colors['white'],
                            'minWidth': '100px',
                            'width': '100px',
                            'maxWidth': '180px',
                            'textAlign' : 'center'},
                        #fixed_columns={'headers': True, 'data': 1},
                        style_table={'overflowX': 'auto','minWidth':'100%'},
                        #cell_selectable = False,
                        sort_action='native',
                        sort_mode='multi',
                        column_selectable = False,
                        page_size=10,
                        editable=True,
                        row_deletable=True,
                        #export_format='xlsx',
                        css=[{ 'selector': '.previous-page, .next-page', 'rule': 'background-color: white;' }],
                    )#,
                    #html.Button('Add Row', id='editing-rows-button-mobile', n_clicks=0),
                ],
                className = 'col-12'
                )
            ],
            className = 'row',
            style = patientdiv
            ),# Internal row - patient list

            html.Div([ # Internal row

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='age-distribution-mobile')
                ],
                className = 'col-12')

            ],
            className = 'row'), # Internal row

            html.Div([ # Internal row

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='hypertension-by-classification-mobile')
                ],
                className = 'col-12'),

            ],
            className = 'row'), # Internal row

            html.Div([ # Internal row

                # Chart Column
                html.Div([
                    dcc.Graph(
                        id='pcv-vs-hemo-mobile')
                ],
                className = 'col-12'),

            ],
            className = 'row') # Internal row


        ],
        className = 'col-10',
        style = externalgraph_colstyling), # External 10-column

        html.Div([
        ],
        className = 'col-1', style={'background-color' : techstat_colors['dark-blue']}), # Blank 1 column

    ],
    className = 'row',
    style = externalgraph_rowstyling
    ), # External row

])

# User status management views


# Login screen
login = html.Div([dcc.Location(id='url_login', refresh=True),
                  html.H2('''Please log in to continue:''', id='h1',style={'background-color' : techstat_colors['superdark-blue']}),
                  dcc.Input(placeholder='Enter your username',
                            type='text', id='uname-box'),
                  dcc.Input(placeholder='Enter your password',
                            type='password', id='pwd-box'),
                  html.Button(children='Login', n_clicks=0,
                              type='submit', id='login-button'),
                  html.Div(children='', id='output-state',style={'background-color' : techstat_colors['superdark-blue']}),
                  html.Br(),
                  dcc.Link('Home', href='/')],style={'background-color' : techstat_colors['superdark-blue']})


# Successful login
success = html.Div([html.Div([html.H2('Login successful.'),
                              html.Br(),
                              dcc.Link('Home', href='/'),
                              html.Br(),
                              dcc.Link('Provider Overview', href='/apps/provider')])  # end div
                    ])  # end div

# Failed Login
failed = html.Div([html.Div([html.H2('Login Failed. Please try again.'),
                             html.Br(),
                             html.Div([login]),
                             dcc.Link('Home', href='/')
                             ])  # end div
                   ])  # end div

# logout
logout = html.Div([html.Div(html.H2('You have been logged out - Please login'),style={'background-color' : techstat_colors['superdark-blue']}),
                   html.Br(),
                   dcc.Link('Home', href='/')
                   ])  # end div
